GKMLL MANUSCRIPT - NATURAL SCIENCES PUBLISHING LATEX PROJECT

Main file: GKMLL_manuscript.tex
Compiled manuscript: GKMLL_manuscript.pdf

COMPILATION
Open GKMLL_manuscript.tex as the main document and select pdfLaTeX.
Compile twice to update the final-page reference and internal links:

    pdflatex GKMLL_manuscript.tex
    pdflatex GKMLL_manuscript.tex

No BibTeX or Biber run is required. The complete bibliography is included
in the main .tex file. All required local class, style, logo, and figure
files are included. Standard TeX packages must be installed; a normal
TeX Live or MiKTeX installation provides them.

TEMPLATE
The supplied NSP1.cls is unchanged from 45c843tvg4gg8h (1).zip.
The project uses the template's two-column Applied Mathematics &
Information Sciences layout. The supplied psfig.sty, everyshi.sty and
logo7pt.eps are retained; logo7pt.pdf supports direct PDF compilation.

CONTENTS
The complete manuscript has been converted from:
GKMLL -paper 2-9-9-2026.docx

The conversion retains the original wording, author and affiliation
information, mathematical expressions, numerical values, captions,
acknowledgment, and bibliography. It includes:

    13 numbered figures, using all 21 original image assets;
    11 numbered tables, with editable LaTeX cells;
    43 numbered equations, plus all unnumbered and inline mathematics;
    44 reference entries, in their original order.

The equations and tables are editable LaTeX, not screenshots. Long
formulas have been reflowed across lines where necessary. Original EMF
figures were exported to vector PDF without replotting the data, and
original PNG figures were retained. Captions and numbering are retained.
Page and column breaks necessarily differ from the Word document.
The compiled manuscript contains 27 pages.

No scientific or editorial corrections have been made to the manuscript.
Any existing inconsistencies in notation, numerical values, wording,
references, or cross-references remain as supplied.

PUBLICATION METADATA
Volume, issue, and publication year remain xx, x, and 20xx because these
were not provided. No received, revised, or accepted dates were invented.
The template class's filename-generated DOI is suppressed in the main
file so that a nonexistent DOI is not displayed. These publication fields
can be completed by the publisher.

FILES
GKMLL_manuscript.tex   Complete editable manuscript
GKMLL_manuscript.pdf   Compiled manuscript
NSP1.cls              Original publisher class
psfig.sty             Supplied supporting style
everyshi.sty          Supplied supporting style
logo7pt.eps           Supplied publisher logo
logo7pt.pdf           PDF version of the supplied logo
figures/              Original figures in PDF or PNG form

